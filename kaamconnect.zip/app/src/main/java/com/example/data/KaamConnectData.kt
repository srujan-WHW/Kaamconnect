package com.example.data

data class WorkerProfile(
    val id: String = "w1",
    val name: String = "Ramesh Kumar",
    val phone: String = "+91 98765 43210",
    val skills: List<String> = listOf("Electrician", "Wiring", "Inverter Repair"),
    val experienceYears: Int = 5,
    val location: String = "Bhadravathi",
    val pincode: String = "577301",
    val availability: String = "Available Today",
    val hourlyRate: Int = 350,
    val rating: Float = 4.8f,
    val reviewsCount: Int = 24,
    val verified: Boolean = true,
    val bio: String = "Certified senior electrician with 5+ years experience in residential and commercial wiring."
)

data class EmployerProfile(
    val id: String = "e1",
    val name: String = "Suresh Patil",
    val businessName: String = "Patil Builders & Electricals",
    val phone: String = "+91 91234 56789",
    val location: String = "Bhadravathi",
    val pincode: String = "577301",
    val rating: Float = 4.9f,
    val reviewsCount: Int = 18,
    val verified: Boolean = true
)

data class Job(
    val id: String,
    val title: String,
    val description: String,
    val employerId: String,
    val employerName: String,
    val skillsRequired: List<String>,
    val location: String,
    val pincode: String,
    val wageAmount: Int,
    val wageType: String, // "Hourly", "Daily", "Fixed"
    val workDate: String, // "Today", "Tomorrow", etc.
    val duration: String, // "4 hours", "1 day", etc.
    val workersRequired: Int,
    val status: String, // "Active", "Filled", "Completed"
    val createdAt: Long = System.currentTimeMillis()
)

data class JobApplication(
    val id: String,
    val jobId: String,
    val jobTitle: String,
    val employerId: String,
    val employerName: String,
    val workerId: String,
    val workerName: String,
    val workerSkills: List<String>,
    val wageOffer: Int,
    var status: String, // "Pending", "Accepted", "Rejected", "Completed"
    val appliedAt: Long = System.currentTimeMillis()
)

data class Message(
    val id: String,
    val senderId: String,
    val senderName: String,
    val receiverId: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val jobTitle: String
)

data class Review(
    val id: String,
    val targetId: String, // workerId or employerId
    val targetType: String, // "worker" or "employer"
    val authorName: String,
    val rating: Float,
    val comment: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AppNotification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    var isRead: Boolean = false,
    val type: String // "job", "application", "message", "system"
)

object InitialData {
    val initialJobs = listOf(
        Job(
            id = "j1",
            title = "Residential House Wiring & Switchboard Setup",
            description = "Need an experienced electrician for complete 3BHK house wiring and MCB box installation in New Town Bhadravathi.",
            employerId = "e1",
            employerName = "Suresh Patil",
            skillsRequired = listOf("Electrician", "Wiring"),
            location = "Bhadravathi",
            pincode = "577301",
            wageAmount = 1200,
            wageType = "Daily",
            workDate = "Today",
            duration = "2 days",
            workersRequired = 2,
            status = "Active"
        ),
        Job(
            id = "j2",
            title = "Commercial Plumbing Maintenance & Pipe Fixing",
            description = "Urgent requirement for plumber to fix leakage in commercial complex near Main Market.",
            employerId = "e2",
            employerName = "Anand Gowda",
            skillsRequired = listOf("Plumber", "Pipe Fitting"),
            location = "Shimoga",
            pincode = "577201",
            wageAmount = 1500,
            wageType = "Daily",
            workDate = "Tomorrow",
            duration = "1 day",
            workersRequired = 1,
            status = "Active"
        ),
        Job(
            id = "j3",
            title = "Interior Wall Painting & Primer Application",
            description = "Looking for skilled painters for 2 floor villa painting. Material will be provided.",
            employerId = "e3",
            employerName = "Manjunath Rao",
            skillsRequired = listOf("Painter", "Wall Putty"),
            location = "Bhadravathi",
            pincode = "577302",
            wageAmount = 1000,
            wageType = "Daily",
            workDate = "Today",
            duration = "3 days",
            workersRequired = 3,
            status = "Active"
        ),
        Job(
            id = "j4",
            title = "Carpentry - Custom Wardrobe & Door Fitting",
            description = "Carpenter needed for modular kitchen cabinet assembly and door frame fitting.",
            employerId = "e1",
            employerName = "Suresh Patil",
            skillsRequired = listOf("Carpenter", "Woodwork"),
            location = "Bhadravathi",
            pincode = "577301",
            wageAmount = 1400,
            wageType = "Daily",
            workDate = "Next Monday",
            duration = "4 days",
            workersRequired = 1,
            status = "Active"
        ),
        Job(
            id = "j5",
            title = "Construction Helper / Mason Assistant",
            description = "General construction labor needed for bricklaying and concrete mixing.",
            employerId = "e2",
            employerName = "Anand Gowda",
            skillsRequired = listOf("Construction", "Masonry"),
            location = "Bhadravathi",
            pincode = "577301",
            wageAmount = 850,
            wageType = "Daily",
            workDate = "Today",
            duration = "1 week",
            workersRequired = 5,
            status = "Active"
        )
    )

    val initialWorkers = listOf(
        WorkerProfile(
            id = "w1",
            name = "Ramesh Kumar",
            phone = "+91 98765 43210",
            skills = listOf("Electrician", "Wiring", "Inverter Repair"),
            experienceYears = 5,
            location = "Bhadravathi",
            pincode = "577301",
            availability = "Available Today",
            hourlyRate = 350,
            rating = 4.8f,
            reviewsCount = 24,
            verified = true,
            bio = "Certified senior electrician with 5+ years experience."
        ),
        WorkerProfile(
            id = "w2",
            name = "Kiran Murthy",
            phone = "+91 98111 22334",
            skills = listOf("Plumber", "Pipe Fitting", "Bathroom Repair"),
            experienceYears = 7,
            location = "Shimoga",
            pincode = "577201",
            availability = "Available Today",
            hourlyRate = 400,
            rating = 4.9f,
            reviewsCount = 31,
            verified = true,
            bio = "Expert plumber specializing in leakage fixing and sanitary installation."
        ),
        WorkerProfile(
            id = "w3",
            name = "Govindappa",
            phone = "+91 97444 55667",
            skills = listOf("Painter", "Wall Putty", "Waterproofing"),
            experienceYears = 10,
            location = "Bhadravathi",
            pincode = "577302",
            availability = "Weekdays",
            hourlyRate = 300,
            rating = 4.7f,
            reviewsCount = 19,
            verified = true,
            bio = "Professional painter for residential and commercial buildings."
        )
    )

    val initialApplications = listOf(
        JobApplication(
            id = "a1",
            jobId = "j1",
            jobTitle = "Residential House Wiring & Switchboard Setup",
            employerId = "e1",
            employerName = "Suresh Patil",
            workerId = "w1",
            workerName = "Ramesh Kumar",
            workerSkills = listOf("Electrician", "Wiring"),
            wageOffer = 1200,
            status = "Accepted",
            appliedAt = System.currentTimeMillis() - 3600000 * 4
        )
    )

    val initialMessages = listOf(
        Message(
            id = "m1",
            senderId = "e1",
            senderName = "Suresh Patil",
            receiverId = "w1",
            text = "Hello Ramesh, can you start the wiring work by 9 AM today?",
            timestamp = System.currentTimeMillis() - 3600000 * 2,
            jobTitle = "Residential House Wiring & Switchboard Setup"
        ),
        Message(
            id = "m2",
            senderId = "w1",
            senderName = "Ramesh Kumar",
            receiverId = "e1",
            text = "Yes Sir, I will reach the site by 9:00 AM sharp with my tools.",
            timestamp = System.currentTimeMillis() - 3600000,
            jobTitle = "Residential House Wiring & Switchboard Setup"
        )
    )

    val initialNotifications = listOf(
        AppNotification(
            id = "n1",
            title = "Application Accepted!",
            message = "Suresh Patil accepted your application for Residential House Wiring.",
            timestamp = System.currentTimeMillis() - 3600000 * 3,
            isRead = false,
            type = "application"
        ),
        AppNotification(
            id = "n2",
            title = "New Matching Job",
            message = "New Electrician job posted in Bhadravathi (₹1,200/day).",
            timestamp = System.currentTimeMillis() - 3600000 * 5,
            isRead = true,
            type = "job"
        )
    )
}
