package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.KaamConnectViewModel
import com.example.ui.Screen
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KaamConnectApp()
            }
        }
    }
}

@Composable
fun KaamConnectApp(viewModel: KaamConnectViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            Screen.WELCOME -> WelcomeScreen(viewModel)
            Screen.LOGIN_REGISTRATION -> LoginRegistrationScreen(viewModel)
            Screen.WORKER_DASHBOARD -> WorkerDashboardScreen(viewModel)
            Screen.EMPLOYER_DASHBOARD -> EmployerDashboardScreen(viewModel)
            Screen.FIND_NEARBY_JOBS -> FindNearbyJobsScreen(viewModel)
            Screen.JOB_DETAILS -> JobDetailsScreen(viewModel)
            Screen.POST_JOB -> PostJobScreen(viewModel)
            Screen.APPLICATIONS -> ApplicationsScreen(viewModel)
            Screen.WORKER_SEARCH -> WorkerSearchScreen(viewModel)
            Screen.MESSAGING -> MessagingScreen(viewModel)
            Screen.NOTIFICATIONS -> NotificationsScreen(viewModel)
            Screen.PROFILE_SETTINGS -> ProfileSettingsScreen(viewModel)
            Screen.RATINGS_REVIEWS -> RatingsReviewsScreen(viewModel)
            else -> WelcomeScreen(viewModel)
        }

        VoiceSearchModal(viewModel)
    }
}
