package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.KaamConnectViewModel
import com.example.ui.Screen
import com.example.ui.theme.DeepBlue
import com.example.ui.theme.SecondaryOrange

@Composable
fun WelcomeScreen(viewModel: KaamConnectViewModel) {
    val language by viewModel.currentLanguage.collectAsState()

    val titleText = when (language) {
        "kn" -> "ಕಾಮ್‌ಕನೆಕ್ಟ್ (KaamConnect)"
        "hi" -> "काम कनेक्ट (KaamConnect)"
        else -> "KaamConnect"
    }

    val subtitleText = when (language) {
        "kn" -> "ಸ್ಥಳೀಯ ಕೆಲಸಗಾರರು ಮತ್ತು ಉದ್ಯೋಗದಾತರ ವಿಶ್ವಾಸಾರ್ಹ ವೇದಿಕೆ"
        "hi" -> "स्थानीय कामगारों और नियोक्ताओं का भरोसेमंद मंच"
        else -> "Connecting Local Workers & Employers Instantly"
    }

    val getStartedText = when (language) {
        "kn" -> "ಪ್ರಾರಂಭಿಸಿ"
        "hi" -> "शुरू करें"
        else -> "Get Started"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DeepBlue, Color(0xFF0F172A))
                )
            )
            .padding(24.dp)
    ) {
        // Language Selector top right
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.Language, contentDescription = "Language", tint = Color.White)
            TextButton(onClick = { viewModel.setLanguage("en") }) {
                Text("EN", color = if (language == "en") SecondaryOrange else Color.White, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = { viewModel.setLanguage("kn") }) {
                Text("ಕನ್ನಡ", color = if (language == "kn") SecondaryOrange else Color.White, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = { viewModel.setLanguage("hi") }) {
                Text("हिंदी", color = if (language == "hi") SecondaryOrange else Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(SecondaryOrange),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Work,
                    contentDescription = "Logo",
                    tint = Color.White,
                    modifier = Modifier.size(56.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = titleText,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = subtitleText,
                fontSize = 16.sp,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))

            Button(
                onClick = { viewModel.navigateTo(Screen.LOGIN_REGISTRATION) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SecondaryOrange)
            ) {
                Text(
                    text = getStartedText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Supporting Electricians, Plumbers, Painters, Carpenters & Daily Wage Workers",
                fontSize = 12.sp,
                color = Color(0xFF64748B),
                textAlign = TextAlign.Center
            )
        }
    }
}
