package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class UserRole {
    NONE, WORKER, EMPLOYER
}

enum class Screen {
    WELCOME,
    LOGIN_REGISTRATION,
    ROLE_SELECTION,
    WORKER_PROFILE_SETUP,
    EMPLOYER_PROFILE_SETUP,
    WORKER_DASHBOARD,
    EMPLOYER_DASHBOARD,
    FIND_NEARBY_JOBS,
    JOB_DETAILS,
    POST_JOB,
    APPLICATIONS,
    WORKER_SEARCH,
    MESSAGING,
    NOTIFICATIONS,
    PROFILE_SETTINGS,
    RATINGS_REVIEWS,
    TRUST_SAFETY
}

class KaamConnectViewModel : ViewModel() {
    private val _currentScreen = MutableStateFlow(Screen.WELCOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _userRole = MutableStateFlow(UserRole.NONE)
    val userRole: StateFlow<UserRole> = _userRole.asStateFlow()

    private val _workerProfile = MutableStateFlow(InitialData.initialWorkers[0])
    val workerProfile: StateFlow<WorkerProfile> = _workerProfile.asStateFlow()

    private val _employerProfile = MutableStateFlow(
        EmployerProfile(
            id = "e1",
            name = "Suresh Patil",
            businessName = "Patil Builders & Electricals",
            phone = "+91 91234 56789",
            location = "Bhadravathi",
            pincode = "577301",
            rating = 4.9f,
            reviewsCount = 18,
            verified = true
        )
    )
    val employerProfile: StateFlow<EmployerProfile> = _employerProfile.asStateFlow()

    private val _jobs = MutableStateFlow(InitialData.initialJobs)
    val jobs: StateFlow<List<Job>> = _jobs.asStateFlow()

    private val _workers = MutableStateFlow(InitialData.initialWorkers)
    val workers: StateFlow<List<WorkerProfile>> = _workers.asStateFlow()

    private val _applications = MutableStateFlow(InitialData.initialApplications)
    val applications: StateFlow<List<JobApplication>> = _applications.asStateFlow()

    private val _messages = MutableStateFlow(InitialData.initialMessages)
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    private val _reviews = MutableStateFlow<List<Review>>(
        listOf(
            Review("r1", "w1", "worker", "Suresh Patil", 5.0f, "Very skilled and punctual electrician."),
            Review("r2", "e1", "employer", "Ramesh Kumar", 5.0f, "Fair wages and clear instructions.")
        )
    )
    val reviews: StateFlow<List<Review>> = _reviews.asStateFlow()

    private val _notifications = MutableStateFlow(InitialData.initialNotifications)
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _currentLanguage = MutableStateFlow("en") // "en", "kn", "hi"
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _selectedJob = MutableStateFlow<Job?>(null)
    val selectedJob: StateFlow<Job?> = _selectedJob.asStateFlow()

    // Search & Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedSkillFilter = MutableStateFlow("All")
    val selectedSkillFilter: StateFlow<String> = _selectedSkillFilter.asStateFlow()

    private val _selectedLocationFilter = MutableStateFlow("All")
    val selectedLocationFilter: StateFlow<String> = _selectedLocationFilter.asStateFlow()

    private val _voiceSearchActive = MutableStateFlow(false)
    val voiceSearchActive: StateFlow<Boolean> = _voiceSearchActive.asStateFlow()

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setUserRole(role: UserRole) {
        _userRole.value = role
    }

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
    }

    fun selectJob(job: Job) {
        _selectedJob.value = job
        navigateTo(Screen.JOB_DETAILS)
    }

    fun updateWorkerProfile(updated: WorkerProfile) {
        _workerProfile.value = updated
    }

    fun updateEmployerProfile(updated: EmployerProfile) {
        _employerProfile.value = updated
    }

    fun postJob(
        title: String,
        description: String,
        skills: List<String>,
        location: String,
        pincode: String,
        wage: Int,
        wageType: String,
        workDate: String,
        duration: String,
        workersRequired: Int
    ) {
        val newJob = Job(
            id = "j_${System.currentTimeMillis()}",
            title = title,
            description = description,
            employerId = _employerProfile.value.id,
            employerName = _employerProfile.value.name,
            skillsRequired = skills,
            location = location,
            pincode = pincode,
            wageAmount = wage,
            wageType = wageType,
            workDate = workDate,
            duration = duration,
            workersRequired = workersRequired,
            status = "Active"
        )
        _jobs.update { listOf(newJob) + it }

        // Add notification
        addNotification(
            "Job Posted Successfully",
            "Your job '$title' is now live for nearby workers."
        )
    }

    fun applyForJob(job: Job) {
        val worker = _workerProfile.value
        val existing = _applications.value.any { it.jobId == job.id && it.workerId == worker.id }
        if (!existing) {
            val newApp = JobApplication(
                id = "a_${System.currentTimeMillis()}",
                jobId = job.id,
                jobTitle = job.title,
                employerId = job.employerId,
                employerName = job.employerName,
                workerId = worker.id,
                workerName = worker.name,
                workerSkills = worker.skills,
                wageOffer = job.wageAmount,
                status = "Pending"
            )
            _applications.update { listOf(newApp) + it }
            addNotification(
                "Application Submitted",
                "Successfully applied for ${job.title}."
            )
        }
    }

    fun updateApplicationStatus(appId: String, newStatus: String) {
        _applications.update { list ->
            list.map { app ->
                if (app.id == appId) {
                    app.copy(status = newStatus)
                } else app
            }
        }
        val app = _applications.value.find { it.id == appId }
        if (app != null) {
            addNotification(
                "Application Status: $newStatus",
                "Your application for ${app.jobTitle} was $newStatus."
            )
        }
    }

    fun sendMessage(receiverId: String, receiverName: String, text: String, jobTitle: String) {
        val senderId = if (_userRole.value == UserRole.WORKER) _workerProfile.value.id else _employerProfile.value.id
        val senderName = if (_userRole.value == UserRole.WORKER) _workerProfile.value.name else _employerProfile.value.name

        val msg = Message(
            id = "m_${System.currentTimeMillis()}",
            senderId = senderId,
            senderName = senderName,
            receiverId = receiverId,
            text = text,
            jobTitle = jobTitle
        )
        _messages.update { it + msg }
    }

    fun addReview(targetId: String, targetType: String, rating: Float, comment: String, authorName: String) {
        val rev = Review(
            id = "r_${System.currentTimeMillis()}",
            targetId = targetId,
            targetType = targetType,
            authorName = authorName,
            rating = rating,
            comment = comment
        )
        _reviews.update { listOf(rev) + it }
        addNotification("Review Added", "Thank you for sharing your feedback!")
    }

    fun addNotification(title: String, message: String, type: String = "system") {
        val notif = AppNotification(
            id = "n_${System.currentTimeMillis()}",
            title = title,
            message = message,
            type = type
        )
        _notifications.update { listOf(notif) + it }
    }

    fun markNotificationAsRead(id: String) {
        _notifications.update { list ->
            list.map { if (it.id == id) it.copy(isRead = true) else it }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSkillFilter(skill: String) {
        _selectedSkillFilter.value = skill
    }

    fun setLocationFilter(location: String) {
        _selectedLocationFilter.value = location
    }

    fun setVoiceSearchActive(active: Boolean) {
        _voiceSearchActive.value = active
    }
}
