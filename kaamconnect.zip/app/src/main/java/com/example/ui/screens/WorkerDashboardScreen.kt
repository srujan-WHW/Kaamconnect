package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.KaamConnectViewModel
import com.example.ui.Screen
import com.example.ui.components.JobCard
import com.example.ui.components.StatCard
import com.example.ui.theme.DeepBlue
import com.example.ui.theme.SecondaryOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkerDashboardScreen(viewModel: KaamConnectViewModel) {
    val worker by viewModel.workerProfile.collectAsState()
    val jobs by viewModel.jobs.collectAsState()
    val applications by viewModel.applications.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val unreadNotifs = notifications.count { !it.isRead }

    val myApplications = applications.filter { it.workerId == worker.id }
    val acceptedApps = myApplications.filter { it.status == "Accepted" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SecondaryOrange),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(worker.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(worker.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = SecondaryOrange, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("${worker.location} (${worker.pincode})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.setVoiceSearchActive(true) }) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = "Voice Search", tint = SecondaryOrange)
                    }
                    IconButton(onClick = { viewModel.navigateTo(Screen.NOTIFICATIONS) }) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifs > 0) {
                                    Badge { Text("$unreadNotifs") }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                        }
                    }
                    IconButton(onClick = { viewModel.navigateTo(Screen.PROFILE_SETTINGS) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = true,
                    onClick = {}
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Search, contentDescription = "Find Jobs") },
                    label = { Text("Find Jobs") },
                    selected = false,
                    onClick = { viewModel.navigateTo(Screen.FIND_NEARBY_JOBS) }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Assignment, contentDescription = "Applications") },
                    label = { Text("My Apps") },
                    selected = false,
                    onClick = { viewModel.navigateTo(Screen.APPLICATIONS) }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Message, contentDescription = "Messages") },
                    label = { Text("Chat") },
                    selected = false,
                    onClick = { viewModel.navigateTo(Screen.MESSAGING) }
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Availability Status Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DeepBlue)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Work Status", color = Color(0xFF93C5FD), fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(worker.availability, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Skills: ${worker.skills.joinToString(", ")}", color = Color(0xFFE2E8F0), fontSize = 13.sp)
                        }
                        Button(
                            onClick = { viewModel.navigateTo(Screen.PROFILE_SETTINGS) },
                            colors = ButtonDefaults.buttonColors(containerColor = SecondaryOrange),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Edit", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Quick Stats Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Applied",
                        value = "${myApplications.size}",
                        icon = Icons.Default.WorkOutline,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(Screen.APPLICATIONS) }
                    )
                    StatCard(
                        title = "Accepted",
                        value = "${acceptedApps.size}",
                        icon = Icons.Default.CheckCircle,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(Screen.APPLICATIONS) }
                    )
                    StatCard(
                        title = "Rating",
                        value = "${worker.rating} ★",
                        icon = Icons.Default.Star,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(Screen.RATINGS_REVIEWS) }
                    )
                }
            }

            // Voice Search Banner Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.setVoiceSearchActive(true) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(SecondaryOrange),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = "Voice", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Search Jobs by Voice", fontWeight = FontWeight.Bold, color = DeepBlue)
                            Text("Tap here to speak in Kannada, Hindi or English", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = "Go", tint = DeepBlue)
                    }
                }
            }

            // Nearby Jobs Section Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Matching Nearby Jobs",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = { viewModel.navigateTo(Screen.FIND_NEARBY_JOBS) }) {
                        Text("View All", color = SecondaryOrange)
                    }
                }
            }

            // Jobs list matching worker skills
            items(jobs.filter { job -> job.skillsRequired.any { skill -> worker.skills.contains(skill) } }) { job ->
                JobCard(job = job, onSelect = { viewModel.selectJob(job) }, onApply = { viewModel.applyForJob(job) })
            }
        }
    }
}
