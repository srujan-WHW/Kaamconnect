package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBlue = Color(0xFF1E3A8A)
val PrimaryBlue = Color(0xFF2563EB)
val SecondaryOrange = Color(0xFFF97316)
val AccentOrange = Color(0xFFEA580C)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val TextDark = Color(0xFF0F172A)
val TextMuted = Color(0xFF64748B)

val DarkPrimary = Color(0xFF3B82F6)
val DarkSecondary = Color(0xFFFB923C)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
