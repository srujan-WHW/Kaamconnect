package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.KaamConnectViewModel
import com.example.ui.Screen
import com.example.ui.components.StatCard
import com.example.ui.theme.DeepBlue
import com.example.ui.theme.SecondaryOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployerDashboardScreen(viewModel: KaamConnectViewModel) {
    val employer by viewModel.employerProfile.collectAsState()
    val jobs by viewModel.jobs.collectAsState()
    val applications by viewModel.applications.collectAsState()

    val myJobs = jobs.filter { it.employerId == employer.id }
    val receivedApps = applications.filter { it.employerId == employer.id }
    val pendingApps = receivedApps.filter { it.status == "Pending" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(DeepBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(employer.businessName.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(employer.businessName, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(employer.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.NOTIFICATIONS) }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                    }
                    IconButton(onClick = { viewModel.navigateTo(Screen.PROFILE_SETTINGS) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Dashboard") },
                    selected = true,
                    onClick = {}
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = "Post Work") },
                    label = { Text("Post Work") },
                    selected = false,
                    onClick = { viewModel.navigateTo(Screen.POST_JOB) }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.People, contentDescription = "Workers") },
                    label = { Text("Workers") },
                    selected = false,
                    onClick = { viewModel.navigateTo(Screen.WORKER_SEARCH) }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Assignment, contentDescription = "Applicants") },
                    label = { Text("Applicants") },
                    selected = false,
                    onClick = { viewModel.navigateTo(Screen.APPLICATIONS) }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(Screen.POST_JOB) },
                containerColor = SecondaryOrange,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Post Work")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Employer overview card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DeepBlue)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Employer Portal", color = Color(0xFF93C5FD), fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(employer.location, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Rating: ${employer.rating} ★ (${employer.reviewsCount} reviews)", color = Color(0xFFE2E8F0), fontSize = 13.sp)
                        }
                        Button(
                            onClick = { viewModel.navigateTo(Screen.POST_JOB) },
                            colors = ButtonDefaults.buttonColors(containerColor = SecondaryOrange),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Post", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Post Job", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Stats row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Active Jobs",
                        value = "${myJobs.size}",
                        icon = Icons.Default.Work,
                        modifier = Modifier.weight(1f),
                        onClick = {}
                    )
                    StatCard(
                        title = "Pending Apps",
                        value = "${pendingApps.size}",
                        icon = Icons.Default.PendingActions,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(Screen.APPLICATIONS) }
                    )
                    StatCard(
                        title = "Workers",
                        value = "3 Available",
                        icon = Icons.Default.VerifiedUser,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(Screen.WORKER_SEARCH) }
                    )
                }
            }

            // Posted Jobs header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your Posted Jobs",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = { viewModel.navigateTo(Screen.POST_JOB) }) {
                        Text("+ Post New Job", color = SecondaryOrange)
                    }
                }
            }

            // List of posted jobs
            items(myJobs) { job ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(job.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFFEF3C7)) {
                                Text(job.status, color = Color(0xFFB45309), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(job.description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Wage: ₹${job.wageAmount} / ${job.wageType}", fontWeight = FontWeight.Bold, color = DeepBlue, fontSize = 13.sp)
                            OutlinedButton(
                                onClick = { viewModel.navigateTo(Screen.APPLICATIONS) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("View Applications", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
