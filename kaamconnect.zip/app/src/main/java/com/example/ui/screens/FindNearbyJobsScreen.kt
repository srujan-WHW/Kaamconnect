package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.KaamConnectViewModel
import com.example.ui.Screen
import com.example.ui.components.JobCard
import com.example.ui.theme.DeepBlue
import com.example.ui.theme.SecondaryOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FindNearbyJobsScreen(viewModel: KaamConnectViewModel) {
    val jobs by viewModel.jobs.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedSkill by viewModel.selectedSkillFilter.collectAsState()
    val selectedLocation by viewModel.selectedLocationFilter.collectAsState()

    val skillsList = listOf("All", "Electrician", "Plumber", "Painter", "Carpenter", "Construction")
    val locationsList = listOf("All", "Bhadravathi", "Shimoga")

    val filteredJobs = jobs.filter { job ->
        val matchesSearch = job.title.contains(searchQuery, ignoreCase =true) ||
                job.description.contains(searchQuery, ignoreCase = true) ||
                job.location.contains(searchQuery, ignoreCase = true)
        val matchesSkill = selectedSkill == "All" || job.skillsRequired.contains(selectedSkill)
        val matchesLocation = selectedLocation == "All" || job.location.equals(selectedLocation, ignoreCase = true)
        matchesSearch && matchesSkill && matchesLocation
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Find Nearby Work", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.WORKER_DASHBOARD) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.setVoiceSearchActive(true) }) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = "Voice Search", tint = SecondaryOrange)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Search input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search by skill, title, location or pincode...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Skill Filter Chips
            Column {
                Text("Skills Filter", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(skillsList) { skill ->
                        FilterChip(
                            selected = selectedSkill == skill,
                            onClick = { viewModel.setSkillFilter(skill) },
                            label = { Text(skill) }
                        )
                    }
                }
            }

            // Location Filter Chips
            Column {
                Text("Location Filter", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(locationsList) { loc ->
                        FilterChip(
                            selected = selectedLocation == loc,
                            onClick = { viewModel.setLocationFilter(loc) },
                            label = { Text(loc) }
                        )
                    }
                }
            }

            // Results count
            Text(
                text = "${filteredJobs.size} Jobs Available",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = DeepBlue
            )

            // List of jobs
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredJobs) { job ->
                    JobCard(
                        job = job,
                        onSelect = { viewModel.selectJob(job) },
                        onApply = { viewModel.applyForJob(job) }
                    )
                }
            }
        }
    }
}
